//
//  ViewController.swift
//  RolePlayPicker
//
//  Created by Marcy Thompson on 6/20/16.
//  Copyright © 2016 Marcella Thompson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextView!

    @IBOutlet weak var characterImage: UIImageView!
    
    var characterArray = ["Jace de'Sierra", "Alexia de'Laegan", "Tanner de'Halle", "Mac de'Halle", "Denny de'Halle", "Tal de'Halle", "Ian de'Liraan", "David Jackson", "Cal Remick", "Nolan Aishley", "Rochelle Blair", "Aidan Anderson", "Prince Ivan", "Ellie Duncan", "Jackie Rocelle", "Alek Royston", "Brendan Frost", "Catroina", "Collin Tracy"];
    
    var number: Int = 1000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func randomNumber() -> Int {
        let randomNumber = (Int(arc4random_uniform(UInt32(characterArray.count))))
        
        return randomNumber
        
    }
    
    @IBAction func tappedChooseButton(_ sender: UIButton) {
        number = randomNumber()
        
        nameTextField.text = characterArray[number]
        nameTextField.textAlignment = .center
        nameTextField.textColor = UIColor.init(red: 0.00000, green: 0.501961, blue: 0.501961, alpha: 1.0)
        nameTextField.font = UIFont(name: "American Typewriter", size: 20)
        characterImage.image = UIImage(named: "\(characterArray[number])")
        
        }
}

